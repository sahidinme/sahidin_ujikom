<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}


include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database


require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>kelas">Kelas</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Kelas</h1>
    </div>

<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $id_kelas = $_POST['id_kelas'];  // Mendapatkan ID kelas dari form
    $nama_kelas = $_POST['nama_kelas'];  // Mendapatkan nama kelas dari form
    $jumlah_siswa = $_POST['jumlah_siswa'];  // Mendapatkan jumlah siswa dari form
    $tahun_ajaran = $_POST['tahun_ajaran'];  // Mendapatkan tahun ajaran dari form
    $nip = $_POST['nip'];  // Mendapatkan nip dari form

    // Query untuk mengupdate data kelas
    $query = "UPDATE kelas SET 
                           nama_kelas=?,
                           jumlah_siswa=?,
                           tahun_ajaran=?,
                           nip=?
                           WHERE id_kelas=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("ssssi", $nama_kelas, $jumlah_siswa, $tahun_ajaran, $nip, $id_kelas);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Kelas berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/kelas/';</script>";
    } else {
        echo "Gagal mengupdate kelas.";
    }
} else {
    $id_kelas = $_GET['id_kelas'];  // Mendapatkan ID kelas dari URL
    // Query untuk mendapatkan data kelas berdasarkan ID
    // $query = "SELECT * FROM kelas WHERE id_kelas=?";

    $query = "  SELECT kelas.*, guru.nama_guru 
                FROM kelas 
                JOIN guru ON kelas.nip = guru.nip 
                WHERE kelas.id_kelas = ?";
        
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_kelas);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data kelas
?>
<!-- Form untuk mengupdate data kelas -->
<form method="post" action="update.php">
    <input type="hidden" name="id_kelas" value="<?php echo $row['id_kelas']; ?>">
    <input type="hidden" name="nip"  value="<?php echo $row['nip']; ?>" >

    
    <div class="mb-3">
        <label for="kd_kelas" class="form-label">Kode Kelas :</label>
        <input type="text" class="form-control" id="kd_kelas" name="kd_kelas" value="<?php echo $row['kd_kelas']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="nama_kelas" class="form-label">Nama Kelas :</label>
        <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" value="<?php echo $row['nama_kelas']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="jumlah_siswa" class="form-label">Jumlah Siswa :</label>
        <input type="text" class="form-control" id="jumlah_siswa" name="jumlah_siswa"  value="<?php echo $row['jumlah_siswa']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="tahun_ajaran" class="form-label">Tahun Ajaran :</label>
        <input type="text" class="form-control" id="tahun_ajaran" name="tahun_ajaran"  value="<?php echo $row['tahun_ajaran']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="nip" class="form-label">Nip :</label>
        <input type="text" class="form-control" id="nip" name="nip"  value="<?php echo $row['nip']; ?> - <?php echo $row['nama_guru']; ?>" disabled>
    </div>
    
    <input type="submit" value="Update Kelas" class="btn btn-success">
</form>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>
