<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $nama_user = $_POST['nama_user'];  // Mendapatkan nama_user dari form
    $username = $_POST['username'];  // Mendapatkan username dari form
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);  // Mendapatkan password dari form dan meng-hash-nya
    $role = $_POST['role'];  // Mendapatkan hak akses dari form

    // Query untuk menambahkan pengguna baru ke database
    $query = "INSERT INTO users (nama_user, username, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("ssss", $nama_user, $username, $password, $role);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('User berhasil ditambahkan.');</script>";
    } else {
        echo "Gagal menambahkan pengguna.";
    }
}

require_once '../tamplate/header.php';

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>users">User</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Create</li>
        </ol>
    </nav>

    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah User</h1>
    </div>


    <!-- Form untuk menambah pelajaran baru -->
    <form method="post" action="create.php">

        <div class="mb-3">
            <label for="nama_user" class="form-label">Nama Pengguna :</label>
            <input type="text" class="form-control" id="nama_user" name="nama_user" required>
        </div>

        <div class="mb-3">
            <label for="username" class="form-label">Username :</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password :</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <div class="mb-3">
            <label for="role" class="form-label">Akses :</label>
            <select name="role" id="role" class="form-control">
                <option value="siswa">siswa</option>
                <option value="guru">guru</option>
                <option value="admin">admin</option>
            </select>
        </div>
        <br>
        <input type="submit" value="Tambah Pelajaran" class="btn btn-success">
    </form>

    <br><br>

    </main>
  </div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
