CREATE DATABASE idin;
USE idin;

CREATE TABLE matpel (
    id_matpel INT AUTO_INCREMENT PRIMARY KEY,
    kd_matpel INT UNIQUE,
    nama_matpel VARCHAR(100)
);

CREATE TABLE guru (
    id_guru INT AUTO_INCREMENT PRIMARY KEY,
    nip VARCHAR(20) UNIQUE,
    nama_guru VARCHAR(100),
    tempat_lahir_guru VARCHAR(100),
    tanggal_lahir_guru DATE,
    jenis_kelamin_guru ENUM('L','P'),
    alamat_guru VARCHAR(100),
    telp_guru VARCHAR(100),
    kd_matpel INT,
    FOREIGN KEY (kd_matpel) REFERENCES matpel(kd_matpel)
);

CREATE TABLE kelas (
    id_kelas INT AUTO_INCREMENT PRIMARY KEY,
    kd_kelas INT UNIQUE,
    nama_kelas VARCHAR(50),
    jumlah_siswa INT,
    tahun_ajaran VARCHAR(50),
    nip VARCHAR(20),
    FOREIGN KEY (nip) REFERENCES guru(nip)
);

CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nama_user VARCHAR(100),
    username VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('siswa', 'guru', 'admin')
);

CREATE TABLE siswa (
    id_siswa INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(20) UNIQUE,
    nama_siswa VARCHAR(100),
    tempat_lahir_siswa VARCHAR(100),
    tanggal_lahir_siswa DATE,
    jenis_kelamin_siswa ENUM('pria','wanita'),
    alamat_siswa VARCHAR(100),
    telp_siswa VARCHAR(100),
    nama_wali VARCHAR(100),
    kd_kelas INT,
    FOREIGN KEY (kd_kelas) REFERENCES kelas(kd_kelas),
    username VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('siswa', 'guru', 'admin'),
    status ENUM('aktif', 'tidak')
);

CREATE TABLE absen (
    id_absen INT AUTO_INCREMENT PRIMARY KEY,
    kd_absen INT UNIQUE,
    nama_bulan VARCHAR(100),
    nis VARCHAR(20),
    jumlah_hadir INT,
    alfa INT,
    izin INT,
    sakit INT,
    FOREIGN KEY (nis) REFERENCES siswa(nis)
);

CREATE TABLE nilai (
    id_nilai INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(20),
    kd_matpel INT,
    uts_sem_ganjil INT,
    uas_sem_ganjil INT,
    uts_sem_genap INT,
    uas_sem_genap INT,
    FOREIGN KEY (nis) REFERENCES siswa(nis),
    FOREIGN KEY (kd_matpel) REFERENCES matpel(kd_matpel)
);
