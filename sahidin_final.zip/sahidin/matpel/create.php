<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $kd_matpel = $_POST['kd_matpel'];  // Mendapatkan kode pelajaran dari form
    $nama_matpel = $_POST['nama_matpel'];  // Mendapatkan nama pelajaran dari form

    try {
        // Query untuk menambahkan pelajaran baru ke database
        $query = "INSERT INTO matpel (kd_matpel, nama_matpel) VALUES (?, ?)";
        $stmt = $db->prepare($query);  // Mempersiapkan query
        $stmt->bind_param("ss", $kd_matpel, $nama_matpel);  // Mengikat parameter

        if ($stmt->execute()) {  // Menjalankan query
            echo "<script>alert('Mata Pelajaran berhasil ditambahkan.');</script>";
        } else {
            echo "<script>alert('Gagal menambahkan pelajaran.');</script>";
        }
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            echo "<script>alert('Error: Kode Mata Pelajaran sudah ada.');</script>";
        } else {
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    }
}

require_once '../tamplate/header.php';

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>matpel">Mata Pelajaran</a></li>
            <li class="breadcrumb-item active" aria-current="page">Create</li>
        </ol>
    </nav>

    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Mata Pelajaran</h1>
    </div>

    <!-- Form untuk menambah pelajaran baru -->
    <form method="post" action="create.php">
        <div class="mb-3">
            <label for="kd_matpel" class="form-label">Kode Mata Pelajaran :</label>
            <input type="text" class="form-control" id="kd_matpel" name="kd_matpel" required>
        </div>

        <div class="mb-3">
            <label for="nama_matpel" class="form-label">Nama Mata Pelajaran :</label>
            <input type="text" class="form-control" id="nama_matpel" name="nama_matpel" required>
        </div>
        <input type="submit" value="Tambah Pelajaran" class="btn btn-success">
    </form>
</main>
</div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->

