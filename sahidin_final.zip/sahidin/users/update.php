<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database


require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>users">Users</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update User</h1>
    </div>

<?php

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $id_user = $_POST['id_user'];  // Mendapatkan ID pengguna dari form
    $nama_user = $_POST['nama_user'];  // Mendapatkan nama_user pengguna dari form
    $username = $_POST['username'];  // Mendapatkan username dari form
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_BCRYPT) : null;  // Mendapatkan dan meng-hash password jika diisi
    $role = $_POST['role'];  // Mendapatkan hak akses dari form

    // Query untuk mengupdate data pengguna
    if ($password) {
        $query = "UPDATE users SET nama_user=?, username=?, password=?, role=? WHERE id_user=?";
        $stmt = $db->prepare($query);  // Mempersiapkan query
        $stmt->bind_param("ssssi", $nama_user, $username, $password, $role, $id_user);  // Mengikat parameter
    } else {
        $query = "UPDATE users SET nama_user=?, username=?, role=? WHERE id_user=?";
        $stmt = $db->prepare($query);  // Mempersiapkan query
        $stmt->bind_param("sssi", $nama_user, $username, $role, $id_user);  // Mengikat parameter
    }

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('User berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/users/';</script>";
    } else {
        echo "Gagal mengupdate pengguna.";
    }
} else {
    $id_user = $_GET['id_user'];  // Mendapatkan ID pengguna dari URL
    // Query untuk mendapatkan data pengguna berdasarkan ID
    $query = "SELECT * FROM users WHERE id_user=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_user);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data pengguna
?>

<!-- Form untuk mengupdate data pelajaran -->
<form method="post" action="">

    <input type="hidden" class="form-control" id="id_user" name="id_user" value="<?php echo $row['id_user']; ?>">
    <input type="hidden" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>">
    <input type="hidden" class="form-control" id="role" name="role" value="<?php echo $row['role']; ?>">

    <div class="mb-3">
        <label for="nama_user" class="form-label">Nama Pengguna :</label>
        <input type="text" class="form-control" id="nama_user" name="nama_user" value="<?php echo $row['nama_user']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="username" class="form-label">Username :</label>
        <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password :</label>
        <input type="password" class="form-control" id="password" name="password" value="" >
        <small id="password" class="form-text text-muted">kosongkan jika tidak ingin merubah</small>
    </div>

    <div class="mb-3">
        <label for="role" class="form-label">Akses :</label>
        <input type="text" class="form-control" id="" name="" value="<?php echo $row['role']; ?>" disabled>
    </div>

    <input type="submit" value="Update Pelajaran" class="btn btn-success">
</form>

<br>
<br>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>

