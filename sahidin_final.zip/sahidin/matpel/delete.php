<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

// Memproses penghapusan artikel jika ID diberikan
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id_matpel"])) {
    $id_matpel = $_GET["id_matpel"];

    // Membuat query untuk menghapus artikel dari database
    $sql = "DELETE FROM matpel WHERE id_matpel = $id_matpel";

    try {
        if ($db->query($sql) === TRUE) {
            // Artikel berhasil dihapus, tampilkan pesan dan redirect ke halaman utama
            echo "<script>alert('Pelajaran berhasil dihapus!');</script>";
            echo "<script>window.location.href = 'http://localhost/sahidin/matpel/';</script>";
            exit();
        } else {
            // Gagal menghapus artikel, tampilkan pesan error
            throw new Exception("Gagal menghapus pelajaran. Kesalahan: " . $db->error);
        }
    } catch (mysqli_sql_exception $e) {
        // Menangkap kesalahan MySQL dan menampilkan pesan kustom
        echo "<script>alert('Error: Tidak dapat menghapus pelajaran karena terkait dengan data guru.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/matpel/';</script>";
        exit();
    } catch (Exception $e) {
        // Menangkap kesalahan lainnya dan menampilkan pesan kustom
        echo "<script>alert('" . $e->getMessage() . "');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/matpel/';</script>";
        exit();
    }
}
?>
