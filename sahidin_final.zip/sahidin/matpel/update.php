<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database


require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>matpel">Mata Pelajaran</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Mata Pelajaran</h1>
    </div>

<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $id_matpel = $_POST['id_matpel'];  // Mendapatkan ID mata pelajaran dari form
    $nama_matpel = $_POST['nama_matpel'];  // Mendapatkan nama mata pelajaran dari form


    // Query untuk mengupdate data pelajaran
    $query = "UPDATE matpel SET nama_matpel=? WHERE id_matpel=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("si", $nama_matpel, $id_matpel);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Pelajaran berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/matpel/';</script>";

    } else {
        echo "Gagal mengupdate pelajaran.";
    }
} else {
    $id_matpel = $_GET['id_matpel'];  // Mendapatkan ID pelajaran dari URL
    // Query untuk mendapatkan data pelajaran berdasarkan ID
    $query = "SELECT * FROM matpel WHERE id_matpel=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_matpel);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data pelajaran
?>
<!-- Form untuk mengupdate data pelajaran -->
<form method="post" action="">

    <input type="hidden" class="form-control" id="id_matpel" name="id_matpel" value="<?php echo $row['id_matpel']; ?>">

    <div class="mb-3">
        <label for="kd_matpel" class="form-label">Kode Pelajaran :</label>
        <input type="text" class="form-control" id="kd_matpel" name="kd_matpel" value="<?php echo $row['kd_matpel']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="nama_matpel" class="form-label">Nama Pelajaran :</label>
        <input type="text" class="form-control" id="nama_matpel" name="nama_matpel" value="<?php echo $row['nama_matpel']; ?>" required>
    </div>

    <input type="submit" value="Update Pelajaran" class="btn btn-success">
</form>

<br>
<br>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>

