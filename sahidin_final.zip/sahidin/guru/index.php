<?php
include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

// Query untuk membaca data kelas
// $query = "SELECT * FROM guru";

$query = "SELECT 
                guru.*, 
                matpel.nama_matpel 
            FROM 
                guru 
            JOIN 
                matpel 
            ON 
                guru.kd_matpel = matpel.kd_matpel
            ORDER BY 
                guru.id_guru DESC ";
$result = $db->query($query);

require_once '../tamplate/header.php';

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item active"><a href="<?php echo BASE_URL; ?>guru">Guru</a></li>
        <!-- <li class="breadcrumb-item active" aria-current="page">Data</li> -->
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Guru</h1>
    </div>

    <div class="alert alert-warning" role="alert">
        <p>Sebelum menghapus data guru, hapus terlebih dahulu data mata pelajaran terkait</u>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"  style="float: right;"></button>
        </p>
    </div>

    <h2><a href="create.php" class="btn btn-success">Tambah</a></h2><br>
    
    <div class="table-responsive">
        <table id="siswaTable" class="table table-striped dt-responsive nowrap" style="width:100%">
          <thead>
            <tr>
                <th>No</th>
                <th>NIP</th>
                <th>Nama Guru</th>
                <th>Tempat Lahir</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>No TLP</th>
                <th>Mata Pelajaran</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = "1"; if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $row['nip']; ?></td>
                        <td><?= $row['nama_guru']; ?></td>
                        <td><?= $row['tempat_lahir_guru']; ?></td>
                        <td><?= $row['tanggal_lahir_guru']; ?></td>
                        <td><?= $row['jenis_kelamin_guru']; ?></td>
                        <td><?= $row['alamat_guru']; ?></td>
                        <td><?= $row['telp_guru']; ?></td>
                        <td><?= $row['nama_matpel']; ?></td>
                        <td class="action-buttons">
                            <a href="update.php?id_guru=<?= $row['id_guru']; ?>" class="btn btn-warning m-2">Update</a>
                            <a href="delete.php?id_guru=<?= $row['id_guru']; ?>" class="btn btn-danger m-2">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data guru.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <br><br>
    </div>
      
      </main>
    </div>
  </div>    
  
  <!-- footer -->
  <?php
  
  require_once '../tamplate/footer.php';
  
  ?>

  <!-- end footer -->

  
