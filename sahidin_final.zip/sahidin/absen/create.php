<?php
include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $kd_absen           = $_POST['kd_absen'];  // Mendapatkan nilai kd_absen dari form
    $nama_bulan         = $_POST['nama_bulan'];  // Mendapatkan nama_bulan dari form
    $nis                = $_POST['nis'];  // Mendapatkan nilai NIP dari form
    $jumlah_hadir       = $_POST['jumlah_hadir'];  // Mendapatkan jumlah_hadir dari form
    $alfa               = $_POST['alfa'];  // Mendapatkan alfa dari form
    $izin               = $_POST['izin'];  // Mendapatkan izin dari form
    $sakit              = $_POST['sakit'];  // Mendapatkan sakit dari form

    try {
        // Query untuk menambahkan data absen baru ke database
        $query = "INSERT INTO absen ( 
            kd_absen, 
            nama_bulan, 
            nis,  
            jumlah_hadir, 
            alfa, 
            izin, 
            sakit) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);  // Mempersiapkan query
        $stmt->bind_param("issiiii", 
                          $kd_absen, 
                          $nama_bulan, 
                          $nis,
                          $jumlah_hadir,
                          $alfa,
                          $izin,
                          $sakit);  // Mengikat parameter

        if ($stmt->execute()) {  // Menjalankan query
            echo "<script>alert('Absen berhasil ditambahkan.');</script>";
        } else {
            echo "<script>alert('Gagal menambahkan Absen.');</script>";
        }
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            echo "<script>alert('Error: Kode Absen sudah ada.');</script>";
        } else {
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    }
}

// header
require_once '../tamplate/header.php';
// end header
?>

<!-- side bar -->
<?php require_once '../tamplate/sidebar.php'; ?>
<!-- end sidebar -->

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>absen">Absen</a></li>
            <li class="breadcrumb-item active" aria-current="page">Create</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Data Absen</h1>
    </div>

    <!-- Form untuk menambah data absen baru -->
    <form method="post" action="create.php">

        <div class="mb-3">
            <label for="kd_absen" class="form-label">Kode Absen :</label>
            <input type="text" class="form-control" id="kd_absen" name="kd_absen" required>
        </div>

        <div class="mb-3">
            <label for="nis" class="form-label">NIS :</label>
            <select name="nis" id="nis" class="form-control">
            <?php
            // Ambil data dari tabel siswa
            $sqlsiswa = "SELECT * FROM siswa ORDER BY id_siswa DESC";
            $resultsiswa = $db->query($sqlsiswa);
            if ($resultsiswa->num_rows > 0) {
                // Output data dari setiap baris
                while ($siswa = $resultsiswa->fetch_assoc()) {
            ?>        
                <option value="<?= $siswa["nis"] ?>"><?= $siswa["nis"] ?> - <?= $siswa["nama_siswa"] ?></option>  
            <?php        
                }
            } else {
                echo "<script>alert('Tidak ada siswa yang ditemukan.');</script>";
            }
            ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="nama_bulan" class="form-label">Nama Bulan :</label>
            <input type="text" class="form-control" id="nama_bulan" name="nama_bulan" required>
        </div>

        <div class="mb-3">
            <label for="jumlah_hadir" class="form-label">Jumlah Hadir :</label>
            <input type="number" class="form-control" id="jumlah_hadir" name="jumlah_hadir" required>
        </div>

        <div class="mb-3">
            <label for="alfa" class="form-label">Alfa :</label>
            <input type="number" class="form-control" id="alfa" name="alfa" required>
        </div>

        <div class="mb-3">
            <label for="izin" class="form-label">Izin :</label>
            <input type="number" class="form-control" id="izin" name="izin" required>
        </div>

        <div class="mb-3">
            <label for="sakit" class="form-label">Sakit :</label>
            <input type="number" class="form-control" id="sakit" name="sakit" required>
        </div>
        
        <input type="submit" value="Tambah Data Absen" class="btn btn-success">

    </form>

    <br><br>

</main>
</div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
