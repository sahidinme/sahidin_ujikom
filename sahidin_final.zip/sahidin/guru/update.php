<?php

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

// hak akses
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: '..'/login.php");
    exit();
}

require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>guru">Guru</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Guru</h1>
    </div>


<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit

    $id_guru                = $_POST['id_guru'];            // Mendapatkan ID guru dari form
    $nip                    = $_POST['nip'];                // Mendapatkan nilai NIP dari form
    $nama_guru              = $_POST['nama_guru'];          // Mendapatkan nama guru dari form
    $tempat_lahir_guru      = $_POST['tempat_lahir_guru'];  // Mendapatkan tempat_lahir_guru dari form
    $tanggal_lahir_guru     = $_POST['tanggal_lahir_guru']; // Mendapatkan tanggal_lahir_guru dari form
    $jenis_kelamin_guru     = $_POST['jenis_kelamin_guru']; // Mendapatkan jenis_kelamin_guru
    $alamat_guru            = $_POST['alamat_guru'];        // Mendapatkan alamat_guru
    $telp_guru              = $_POST['telp_guru'];          // Mendapatkan telp_guru
    $kd_matpel              = $_POST['kd_matpel'];           // Mendapatkan kd_mapel


    // Query untuk mengupdate data guru
    $query = "UPDATE guru SET 
    nip=?, 
    nama_guru=?,
    tempat_lahir_guru=?,      
    tanggal_lahir_guru=?,     
    jenis_kelamin_guru=?,     
    alamat_guru=?,            
    telp_guru=?,              
    kd_matpel=?
    WHERE id_guru=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("ssssssssi", 
    $nip, 
    $nama_guru,
    $tempat_lahir_guru,
    $tanggal_lahir_guru,
    $jenis_kelamin_guru,
    $alamat_guru,
    $telp_guru,
    $kd_matpel, 
    $id_guru);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Guru berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/guru/';</script>";
    } else {
        echo "Gagal mengupdate guru.";
    }
} else {
    $id_guru = $_GET['id_guru'];  // Mendapatkan ID guru dari URL
    // Query untuk mendapatkan data guru berdasarkan ID
    // $query = "SELECT * FROM guru WHERE id_guru=?";

    $query = "  SELECT guru.*, matpel.nama_matpel 
                FROM guru 
                JOIN matpel ON guru.kd_matpel = matpel.kd_matpel 
                WHERE guru.id_guru = ?";

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_guru);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data guru
?>

<!-- Form untuk mengupdate data kelas -->
<form method="post" action="update.php">
    <input type="hidden" name="id_guru" value="<?php echo $row['id_guru']; ?>">
    <input type="hidden" name="nip" value="<?php echo $row['nip']; ?>">
    <input type="hidden" name="jenis_kelamin_guru" value="<?php echo $row['jenis_kelamin_guru']; ?>">
    <input type="hidden" name="kd_matpel" value="<?php echo $row['kd_matpel']; ?>">
    
    <div class="mb-3">
        <label for="nip" class="form-label">Nip :</label>
        <input type="text" class="form-control" id="nip" name="nip" value="<?php echo $row['nip']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="nama_guru" class="form-label">Nama Guru :</label>
        <input type="text" class="form-control" id="nama_guru" name="nama_guru" value="<?php echo $row['nama_guru']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="tempat_lahir_guru" class="form-label">Tempat Lahir Guru :</label>
        <input type="text" class="form-control" id="tempat_lahir_guru" name="tempat_lahir_guru" value="<?php echo $row['tempat_lahir_guru']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="tanggal_lahir_guru" class="form-label">Tanggal Lahir Guru :</label>
        <input type="date" class="form-control" id="tanggal_lahir_guru" name="tanggal_lahir_guru" value="<?php echo $row['tanggal_lahir_guru']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="jenis_kelamin_guru" class="form-label">Jenis Kelamin :</label>
        <input type="text" name="jenis_kelamin_guru" id="jenis_kelamin_guru"  class="form-control" value="<?php echo $row['jenis_kelamin_guru']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="alamat_guru" class="form-label">Alamat Guru :</label>
        <input type="text" class="form-control" id="alamat_guru" name="alamat_guru" value="<?php echo $row['alamat_guru']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="telp_guru" class="form-label">No Telp :</label>
        <input type="text" class="form-control" id="telp_guru" name="telp_guru" value="<?php echo $row['telp_guru']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="telp_guru" class="form-label">Kode Mata Pelajaran :</label>
        <input type="text" class="form-control" id="kd_matpel" name="kd_matpel" value="<?php echo $row['kd_matpel']; ?>" disabled>
    </div>

    <div class="mb-3">
        <label for="telp_guru" class="form-label">Nama Mata Pelajaran :</label>
        <input type="text" class="form-control" id="nama_matpel" name="nama_matpel" value="<?php echo $row['nama_matpel']; ?>" disabled>
    </div>

    <br>
    
    <input type="submit" value="Update Kelas" class="btn btn-success">
</form>
<br><br>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>
