<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru', 'siswa'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $nis                 = $_POST['nis'];  // Mendapatkan nilai NIS dari form
    $nama_siswa          = $_POST['nama_siswa'];  // Mendapatkan nama siswa dari form
    $tempat_lahir_siswa  = $_POST['tempat_lahir_siswa'];  // Mendapatkan tempat lahir siswa dari form
    $tanggal_lahir_siswa = $_POST['tanggal_lahir_siswa'];  // Mendapatkan tempat lahir siswa dari form
    $jenis_kelamin_siswa = $_POST['jenis_kelamin_siswa'];  // Mendapatkan tanggal lahir siswa dari form
    $alamat_siswa        = $_POST['alamat_siswa'];  // Mendapatkan alamat siswa dari form
    $telp_siswa          = $_POST['telp_siswa'];  // Mendapatkan tanggal lahir guru dari form
    $nama_wali           = $_POST['nama_wali'];  // Mendapatkan nama wali dari form
    $kd_kelas            = $_POST['kd_kelas'];  // Mendapatkan kd kelas dari form
    $username            = $_POST['username'];  // Mendapatkan username dari form
    $password            = password_hash($_POST['password'], PASSWORD_BCRYPT);  // Mendapatkan password dari form dan meng-hash-nya
    $role                = "siswa";  // nilai default role 
    $status              = "aktif";  // nilai default status 

    // Query untuk menambahkan guru baru ke database
    $query = "INSERT INTO siswa (
        nis, 
        nama_siswa, 
        tempat_lahir_siswa, 
        tanggal_lahir_siswa,  
        jenis_kelamin_siswa, 
        alamat_siswa, 
        telp_siswa,
        nama_wali,
        kd_kelas,
        username,
        password,
        role,
        status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("isssssssissss", 
                        $nis, 
                        $nama_siswa, 
                        $tempat_lahir_siswa,
                        $tanggal_lahir_siswa,
                        $jenis_kelamin_siswa,
                        $alamat_siswa,
                        $telp_siswa,
                        $nama_wali,
                        $kd_kelas,
                        $username,
                        $password,
                        $role,
                        $status
                    );  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Siswa berhasil ditambahkan.');</script>";
    } else {
        echo "Gagal menambahkan siswa.";
    }
}


// header
require_once '../tamplate/header.php';
// end header

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
        
        <!-- breadcrumb -->

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>siswa">Siswa</a></li>
            <li li class="breadcrumb-item active" aria-current="page">Create</li>
            </ol>
        </nav>

        <!-- end breadcrumb -->
        
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Tambah Siswa</h1>
        </div>

        <!-- Form untuk menambah guru baru -->
        <form method="post" action="create.php">

            <div class="mb-3">
                <label for="nis" class="form-label">Nis :</label>
                <input type="text" class="form-control" id="nis" name="nis" required>
            </div>

            <div class="mb-3">
                <label for="nama_siswa" class="form-label">Nama siswa :</label>
                <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" required>
            </div>

            <div class="mb-3">
                <label for="tempat_lahir_siswa" class="form-label">Tempat Lahir siswa :</label>
                <input type="text" class="form-control" id="tempat_lahir_siswa" name="tempat_lahir_siswa" required>
            </div>

            <div class="mb-3">
                <label for="tanggal_lahir_siswa" class="form-label">Tanggal Lahir siswa :</label>
                <input type="date" class="form-control" id="tanggal_lahir_siswa" name="tanggal_lahir_siswa" required>
            </div>

            <div class="mb-3">
                <label for="jenis_kelamin_siswa" class="form-label">Jenis Kelamin :</label>
                <select name="jenis_kelamin_siswa" id="jenis_kelamin_siswa"  class="form-control">
                    <option value="pria">Pria</option>
                    <option value="wanita">Wanita</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="alamat_siswa" class="form-label">Alamat siswa :</label>
                <input type="text" class="form-control" id="alamat_siswa" name="alamat_siswa" required>
            </div>

            <div class="mb-3">
                <label for="telp_siswa" class="form-label">No Telp :</label>
                <input type="text" class="form-control" id="telp_siswa" name="telp_siswa" required>
            </div>

            <div class="mb-3">
                <label for="nama_wali" class="form-label">Nama Wali :</label>
                <input type="text" class="form-control" id="nama_wali" name="nama_wali" required>
            </div>

            <div class="mb-3">

                <label for="kd_kelas" class="form-label">Kelas :</label>
                <select name="kd_kelas" id="kd_kelas"  class="form-control">
                <?php

                // Ambil data dari tabel matpel
                $sqlkelas = "SELECT * FROM kelas ORDER BY id_kelas DESC";
                $resultkelas = $db->query($sqlkelas);
                if ($resultkelas->num_rows > 0) {
                    // Output data dari setiap baris
                    while ($kelas = $resultkelas->fetch_assoc()) {
                ?>        
                
                <option value="<?= $kelas["kd_kelas"] ?>"><?= $kelas["nama_kelas"] ?></option>  
            
                <?php        
                    }
                } else {
                    echo "Tidak ada mata pelajaran yang ditemukan.";
                }

                ?>
                
                </select>
            </div>

            <div class="mb-3">
                <label for="username" class="form-label">Username :</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password :</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            
            <input type="submit" value="Tambah Siswa" class="btn btn-success">

        </form>

        <br><br>

    </main>
  </div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
