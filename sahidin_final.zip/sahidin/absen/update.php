<?php

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>absen">Absen</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Data Absen</h1>
    </div>


<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit

    $id_absen               = $_POST['id_absen'];            // Mendapatkan ID absen dari form
    $kd_absen               = $_POST['kd_absen'];                // Mendapatkan kd_absen dari form
    $nama_bulan             = $_POST['nama_bulan'];          // Mendapatkan nama bulan dari form
    $nis                    = $_POST['nis'];                // Mendapatkan nilai NIs dari form
    $jumlah_hadir           = $_POST['jumlah_hadir'];          // Mendapatkan jumlah hadir dari form
    $alfa                   = $_POST['alfa'];  // Mendapatkan alfa dari form
    $izin                   = $_POST['izin']; // Mendapatkan izin dari form
    $sakit                  = $_POST['sakit']; // Mendapatkan sakit
             


    // Query untuk mengupdate data guru
    $query = "UPDATE absen SET 
    kd_absen=?, 
    nama_bulan=?,
    nis=?,      
    jumlah_hadir=?,     
    alfa=?,     
    izin=?,            
    sakit=?
    WHERE id_absen=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("issiiiii", 
    $kd_absen, 
    $nama_bulan,
    $nis,
    $jumlah_hadir,
    $alfa,
    $izin,
    $sakit,
    $id_absen);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Absen berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/absen/';</script>";
    } else {
        echo "Gagal mengupdate Absen.";
    }
} else {
    $id_absen = $_GET['id_absen'];  // Mendapatkan ID guru dari URL
    // Query untuk mendapatkan data guru berdasarkan ID
    // $query = "SELECT * FROM guru WHERE id_guru=?";

    $query = "  SELECT absen.*, siswa.nama_siswa 
                FROM absen 
                JOIN siswa ON absen.nis = siswa.nis 
                WHERE absen.id_absen = ?";            

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_absen);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data guru
?>

<!-- Form untuk mengupdate data kelas -->
<form method="post" action="update.php">
    <input type="hidden" name="id_absen" value="<?php echo $row['id_absen']; ?>">
    <input type="hidden" name="nis" value="<?php echo $row['nis']; ?>">
    <input type="hidden" name="kd_absen" value="<?php echo $row['kd_absen']; ?>">
    
    <div class="mb-3">
        <label for="kd_absen" class="form-label">Kode Absen :</label>
        <input type="text" class="form-control" id="kd_absen" name="kd_absen" value="<?php echo $row['kd_absen']; ?>" disabled>
    </div>

    <div class="mb-3">

        <label for="nis" class="form-label">Nis :</label>
        <input type="text" class="form-control" name="nis" value="<?php echo $row['nis']; ?> - <?php echo $row['nama_siswa']; ?> " disabled>
        
    </div>

    <div class="mb-3">
        <label for="bulan" class="form-label">Nama Bulan :</label>
        <input type="text" class="form-control" id="nama_bulan" name="nama_bulan" value="<?php echo $row['nama_bulan']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="jumlah_hadir" class="form-label">Jumlah Hadir :</label>
        <input type="number" class="form-control" id="jumlah_hadir" name="jumlah_hadir" value="<?php echo $row['jumlah_hadir']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="alfa" class="form-label">Alfa :</label>
        <input type="number" class="form-control" id="alfa" name="alfa" value="<?php echo $row['alfa']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="izin" class="form-label">Izin :</label>
        <input type="number" class="form-control" id="izin" name="izin" value="<?php echo $row['izin']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="sakit" class="form-label">Sakit :</label>
        <input type="number" class="form-control" id="sakit" name="sakit" value="<?php echo $row['sakit']; ?>" required>
    </div>

    <br>
    
    <input type="submit" value="Update Absen" class="btn btn-success">
</form>
<br><br>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>
