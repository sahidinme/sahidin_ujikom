<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru', 'siswa'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database


// Memproses penghapusan artikel jika ID diberikan
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id_siswa"])) {
    $id_siswa = $_GET["id_siswa"];

    // Membuat query untuk menghapus artikel dari database
    $sql = "DELETE FROM siswa WHERE id_siswa = $id_siswa";

    if ($db->query($sql) === TRUE) {
        // siswa berhasil dihapus, tampilkan pesan dan redirect ke halaman utama
        echo "<script>alert('Siswa berhasil dihapus!');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/siswa/';</script>";
        exit();
    } else {
        // Gagal menghapus siswa, tampilkan pesan error
        echo "Error: " . $sql . "<br>" . $db->error;
    }
}


?>
