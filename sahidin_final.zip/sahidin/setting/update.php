<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru', 'siswa'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database


require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>siswa">Siswa</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Siswa</h1>
    </div>


<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
        
    $id_siswa               = $_POST['id_siswa'];            // Mendapatkan ID guru dari form
    $nis                    = $_POST['nis'];                // Mendapatkan nilai NIP dari form
    $nama_siswa             = $_POST['nama_siswa'];          // Mendapatkan nama guru dari form
    $tempat_lahir_siswa     = $_POST['tempat_lahir_siswa'];  // Mendapatkan tempat_lahir_guru dari form
    $tanggal_lahir_siswa    = $_POST['tanggal_lahir_siswa']; // Mendapatkan tanggal_lahir_guru dari form
    $jenis_kelamin_siswa    = $_POST['jenis_kelamin_siswa']; // Mendapatkan jenis_kelamin_guru
    $alamat_siswa           = $_POST['alamat_siswa'];        // Mendapatkan alamat_guru
    $telp_siswa             = $_POST['telp_siswa'];          // Mendapatkan telp_guru
    $nama_wali              = $_POST['nama_wali'];           // Mendapatkan kd_mapel
    $kd_kelas               = $_POST['kd_kelas'];
    $username               = $_POST['username'];
    $password               = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_BCRYPT) : null;  // Mendapatkan dan meng-hash password jika diisi
    $role                   = $_POST['role'];
    $status                 = $_POST['status'];


    if($password){

    // Query untuk mengupdate data guru dengan password
    $query = "UPDATE siswa SET 
    nis=?, 
    nama_siswa=?,
    tempat_lahir_siswa=?,      
    tanggal_lahir_siswa=?,     
    jenis_kelamin_siswa=?,     
    alamat_siswa=?,            
    telp_siswa=?,              
    nama_wali=?,              
    kd_kelas=?,              
    username=?,              
    password=?,
    role=?,
    status=?
    WHERE id_siswa=?";

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("sssssssssssssi", 
    $nis, 
    $nama_siswa,
    $tempat_lahir_siswa,
    $tanggal_lahir_siswa,
    $jenis_kelamin_siswa,
    $alamat_siswa,
    $telp_siswa,
    $nama_wali,
    $kd_kelas,
    $username,
    $password, 
    $role, 
    $status, 
    $id_siswa);  // Mengikat parameter


    }else{

    // Query untuk mengupdate data guru tanpa password
    $query = "UPDATE siswa SET 
    nis=?, 
    nama_siswa=?,
    tempat_lahir_siswa=?,      
    tanggal_lahir_siswa=?,     
    jenis_kelamin_siswa=?,     
    alamat_siswa=?,            
    telp_siswa=?,              
    nama_wali=?,              
    kd_kelas=?,              
    username=?,  
    role=?,
    status=?
    WHERE id_siswa=?";

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("ssssssssssssi", 
    $nis, 
    $nama_siswa,
    $tempat_lahir_siswa,
    $tanggal_lahir_siswa,
    $jenis_kelamin_siswa,
    $alamat_siswa,
    $telp_siswa,
    $nama_wali,
    $kd_kelas,
    $username,
    $role, 
    $status, 
    $id_siswa);  // Mengikat parameter
    
    }

    
    
    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Siswa berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/siswa/';</script>";
    } else {
        echo "Gagal mengupdate siswa.";
    }
} else {
    $id_siswa = $_GET['id_siswa'];  // Mendapatkan ID siswa dari URL
    // Query untuk mendapatkan data siswa berdasarkan ID
    // $query = "SELECT * FROM siswa WHERE id_siswa=?";

    $query = "  SELECT siswa.*, kelas.nama_kelas 
                FROM siswa 
                JOIN kelas ON siswa.kd_kelas = kelas.kd_kelas 
                WHERE siswa.id_siswa = ?";

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_siswa);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data siswa
?>
<!-- Form untuk mengupdate data siswa -->
<form method="post" action="update.php">

<input type="hidden" id="id_siswa" name="id_siswa" value="<?php echo $row['id_siswa']; ?>" >
<input type="hidden" id="nis" name="nis" value="<?php echo $row['nis']; ?>" >
<input type="hidden" id="kd_kelas" name="kd_kelas" value="<?php echo $row['kd_kelas']; ?>" >
<input type="hidden" id="role" name="role" value="<?php echo $row['role']; ?>" >
<input type="hidden" id="username" name="username"  value="<?php echo $row['username']; ?>" >


<div class="mb-3">
    <label for="nis" class="form-label">Nis :</label>
    <input type="text" class="form-control" id="nis" name="nis" value="<?php echo $row['nis']; ?>" disabled>
</div>

<div class="mb-3">
    <label for="nama_siswa" class="form-label">Nama siswa :</label>
    <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" value="<?php echo $row['nama_siswa']; ?>" required>
</div>

<div class="mb-3">
    <label for="tempat_lahir_siswa" class="form-label">Tempat Lahir siswa :</label>
    <input type="text" class="form-control" id="tempat_lahir_siswa" name="tempat_lahir_siswa" value="<?php echo $row['tempat_lahir_siswa']; ?>" required>
</div>

<div class="mb-3">
    <label for="tanggal_lahir_siswa" class="form-label">Tanggal Lahir siswa :</label>
    <input type="date" class="form-control" id="tanggal_lahir_siswa" name="tanggal_lahir_siswa" value="<?php echo $row['tanggal_lahir_siswa']; ?>" required>
</div>

<div class="mb-3">
    <label for="jenis_kelamin_siswa" class="form-label">Jenis Kelamin :</label>
    <select name="jenis_kelamin_siswa" id="jenis_kelamin_siswa"  class="form-control">
        <option value="pria" <?php if( $row['jenis_kelamin_siswa'] == 'pria' ) echo 'selected'; ?> >Pria</option>
        <option value="wanita" <?php if( $row['jenis_kelamin_siswa'] == 'wanita' ) echo 'selected'; ?> >Wanita</option>
    </select>
</div>

<div class="mb-3">
    <label for="alamat_siswa" class="form-label">Alamat siswa :</label>
    <input type="text" class="form-control" id="alamat_siswa" name="alamat_siswa" value="<?php echo $row['alamat_siswa']; ?>" required>
</div>

<div class="mb-3">
    <label for="telp_siswa" class="form-label">No Telp :</label>
    <input type="text" class="form-control" id="telp_siswa" name="telp_siswa" value="<?php echo $row['telp_siswa']; ?>" required>
</div>

<div class="mb-3">
    <label for="nama_wali" class="form-label">Nama Wali :</label>
    <input type="text" class="form-control" id="nama_wali" name="nama_wali" value="<?php echo $row['nama_wali']; ?>" required>
</div>

<div class="mb-3">

    <label for="kd_kelas" class="form-label">Kelas :</label>
    <input type="text" name="kd_kelas" id="kd_kelas"  class="form-control" value="<?php echo $row['nama_kelas']; ?>" disabled>
</div>

<div class="mb-3">
    <label for="username" class="form-label">Username :</label>
    <input type="text" class="form-control" id="username" name="username"  value="<?php echo $row['username']; ?>" disabled>
</div>

<div class="mb-3">
    <label for="password" class="form-label">Password :</label>
    <input type="password" class="form-control" id="password" name="password">
    <small id="password" class="form-text text-muted">kosongkan jika tidak ingin merubah</small>
</div>

<div class="mb-3">
    <label for="status" class="form-label">Status :</label>
    <select name="status" id="status"  class="form-control">
        <option value="aktif" <?php if( $row['status'] == 'aktif' ) echo 'selected'; ?> >Aktif</option>
        <option value="tidak" <?php if( $row['status'] == 'tidak' ) echo 'selected'; ?> >Tidak</option>
    </select>
</div>
<br>
<input type="submit" value="Update Siswa" class="btn btn-success">

</form>
<br><br>

<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>