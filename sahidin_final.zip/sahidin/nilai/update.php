<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database


require_once '../tamplate/header.php';
?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->




    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>nilai">Nilai</a></li>
        <li li class="breadcrumb-item active" aria-current="page">Update</li>
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Update Nilai</h1>
    </div>


<?php
$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $id_nilai = $_POST['id_nilai'];  // Mendapatkan ID nilai dari form
    $nis = $_POST['nis'];  // Mendapatkan nilai NIS dari form
    $kd_matpel = $_POST['kd_matpel'];  // Mendapatkan kode matpel
    $uts_sem_ganjil = $_POST['uts_sem_ganjil'];          
    $uas_sem_ganjil = $_POST['uas_sem_ganjil'];          
    $uts_sem_genap = $_POST['uts_sem_genap'];          
    $uas_sem_genap = $_POST['uas_sem_genap'];          

    // Query untuk mengupdate data nilai
    $query = "UPDATE nilai SET 
                nis=?,               
                kd_matpel=?,
                uts_sem_ganjil=?,
                uas_sem_ganjil=?,
                uts_sem_genap=?,
                uas_sem_genap=?
              WHERE id_nilai=?";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("ssssssi", 
        $nis, 
        $kd_matpel, 
        $uts_sem_ganjil, 
        $uas_sem_ganjil, 
        $uts_sem_genap, 
        $uas_sem_genap, 
        $id_nilai);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Nilai berhasil diupdate.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/nilai/';</script>";
    } else {
        echo "Gagal mengupdate nilai.";
    }
} else {
    $id_nilai = $_GET['id_nilai'];  // Mendapatkan id_nilai dari URL
    // Query untuk mendapatkan data guru berdasarkan ID
    // $query = "SELECT * FROM guru WHERE id_guru=?";
    
    $query = "SELECT 
            *
        FROM 
            nilai
        JOIN 
            siswa ON nilai.nis = siswa.nis
        JOIN 
            matpel ON nilai.kd_matpel = matpel.kd_matpel
        WHERE nilai.id_nilai = ?";

    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("i", $id_nilai);  // Mengikat parameter
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $row = $result->fetch_assoc();  // Mengambil data guru
?>

<!-- Form untuk mengupdate data kelas -->
<form method="post" action="update.php">
    <input type="hidden" name="id_nilai" value="<?php echo $row['id_nilai']; ?>">
    <input type="hidden" name="nis" value="<?php echo $row['nis']; ?>">
    <input type="hidden" name="kd_matpel" value="<?php echo $row['kd_matpel']; ?>">

    <div class="mb-3">
        <label for="nis" class="form-label">Nis :</label>
        <input type="text" class="form-control" id="nis" name="nis" value="<?php echo $row['nis']; ?> - <?php echo $row['nama_siswa']; ?> " disabled>
    </div>

    <div class="mb-3">
        <label for="kd_matpel" class="form-label">Kode Mata pelajaran :</label>
        <input type="text" class="form-control" id="kd_matpel" name="kd_matpel" value="<?php echo $row['kd_matpel']; ?> - <?php echo $row['nama_matpel']; ?> " disabled>
    </div>

    <div class="mb-3">
        <label for="uts_sem_ganjil" class="form-label">Nilai UTS Ganjil :</label>
        <input type="text" class="form-control" id="uts_sem_ganjil" name="uts_sem_ganjil" value="<?php echo $row['uts_sem_ganjil']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="uas_sem_ganjil" class="form-label">Nilai UAS Ganjil :</label>
        <input type="text" class="form-control" id="uas_sem_ganjil" name="uas_sem_ganjil" value="<?php echo $row['uas_sem_ganjil']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="uts_sem_genap" class="form-label">Nilai UTS Genap :</label>
        <input type="text" class="form-control" id="uts_sem_genap" name="uts_sem_genap" value="<?php echo $row['uts_sem_genap']; ?>" required>
    </div>

    <div class="mb-3">
        <label for="uas_sem_genap" class="form-label">Nilai UAS Genap :</label>
        <input type="text" class="form-control" id="uas_sem_genap" name="uas_sem_genap" value="<?php echo $row['uas_sem_genap']; ?>" required>
    </div>

    <br>
    
    <input type="submit" value="Update Nilai" class="btn btn-success">
</form>
<br><br>
<?php
}
?>

</main>
  </div>
</div>    

<?php

require_once '../tamplate/footer.php';

?>
