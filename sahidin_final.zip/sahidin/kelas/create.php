<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $kd_kelas = $_POST['kd_kelas'];  // Mendapatkan nama kelas dari form
    $nama_kelas = $_POST['nama_kelas'];  // Mendapatkan nama kelas dari form
    $jumlah_siswa = $_POST['jumlah_siswa'];  // Mendapatkan jumlah siswa dari form
    $tahun_ajaran = $_POST['tahun_ajaran'];  // Mendapatkan tahun_ajaran dari form
    $nip = $_POST['nip'];  // Mendapatkan nip dari form
    
    try {
        // Query untuk menambahkan kelas baru ke database
        $query = "INSERT INTO kelas (kd_kelas, nama_kelas, jumlah_siswa, tahun_ajaran, nip) VALUES (?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);  // Mempersiapkan query
        $stmt->bind_param("issss", $kd_kelas, $nama_kelas, $jumlah_siswa, $tahun_ajaran, $nip);  // Mengikat parameter

        if ($stmt->execute()) {  // Menjalankan query
            echo "<script>alert('Kelas berhasil ditambahkan.');</script>";
        } else {
            echo "<script>alert('Gagal menambahkan kelas.');</script>";
        }
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            echo "<script>alert('Error: Kode Kelas sudah ada.');</script>";
        } else {
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    }
}

// header
require_once '../tamplate/header.php';
// end header

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->


<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>kelas">Kelas</a></li>
            <li class="breadcrumb-item active" aria-current="page">Create</li>
        </ol>
    </nav>

    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Kelas</h1>
    </div>

    <!-- Form untuk menambah kelas baru -->
    <form method="post" action="create.php">

        <div class="mb-3">
            <label for="kd_kelas" class="form-label">Kode Kelas :</label>
            <input type="text" class="form-control" id="kd_kelas" name="kd_kelas" required>
        </div>

        <div class="mb-3">
            <label for="nama_kelas" class="form-label">Nama Kelas :</label>
            <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" required>
        </div>

        <div class="mb-3">
            <label for="jumlah_siswa" class="form-label">Jumlah Siswa :</label>
            <input type="text" class="form-control" id="jumlah_siswa" name="jumlah_siswa" required>
        </div>

        <div class="mb-3">
            <label for="tahun_ajaran" class="form-label">Tahun Ajaran :</label>
            <input type="text" class="form-control" id="tahun_ajaran" name="tahun_ajaran" required>
        </div>

        <div class="mb-3">
            <label for="nip" class="form-label">Nip :</label>
            <select name="nip" id="nip"  class="form-control">
            <?php
            // Ambil data dari tabel guru
            $sqlguru = "SELECT * FROM guru ORDER BY id_guru DESC";
            $resultguru = $db->query($sqlguru);
            if ($resultguru->num_rows > 0) {
                // Output data dari setiap baris
                while ($guru = $resultguru->fetch_assoc()) {
            ?>        
                <option value="<?= $guru["nip"] ?>"><?= $guru["nip"] ?> - <?= $guru["nama_guru"] ?></option>  
            <?php        
                }
            } else {
                echo "Tidak ada guru yang ditemukan.";
            }
            ?>
            </select>
        </div>

        <input type="submit" value="Tambah Kelas" class="btn btn-success">
    </form>
</main>
</div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
