<?php

// memulai session
session_start();

// membatasi akses
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $nis                = $_POST['nis'];  // Mendapatkan nilai NIS dari form
    $kd_matpel          = $_POST['kd_matpel'];  // Mendapatkan kd matpel dari form
    $uts_sem_ganjil     = $_POST['uts_sem_ganjil'];
    $uas_sem_ganjil     = $_POST['uas_sem_ganjil'];
    $uts_sem_genap      = $_POST['uts_sem_genap'];
    $uas_sem_genap      = $_POST['uas_sem_genap'];


    // Query untuk menambahkan guru baru ke database
    $query = "INSERT INTO nilai (
    nis, 
    kd_matpel,
    uts_sem_ganjil,
    uas_sem_ganjil,
    uts_sem_genap,
    uas_sem_genap) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("issssi", 
                        $nis, 
                        $kd_matpel,
                        $uts_sem_ganjil,
                        $uas_sem_ganjil,
                        $uts_sem_genap,
                        $uas_sem_genap);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Nilai berhasil ditambahkan.');</script>";
    } else {
        echo "Gagal menambahkan guru.";
    }
}

// header
require_once '../tamplate/header.php';
// end header

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
        
        <!-- breadcrumb -->

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>nilai">Nilai</a></li>
            <li li class="breadcrumb-item active" aria-current="page">Create</li>
            </ol>
        </nav>

        <!-- end breadcrumb -->
        
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Tambah Nilai</h1>
        </div>

        <!-- Form untuk menambah guru baru -->
        <form method="post" action="create.php">

            <div class="mb-3">

                <label for="nis" class="form-label">Nis :</label>
                <select name="nis" id="nis"  class="form-control">
                <?php

                // Ambil data dari tabel matpel
                $sqlsiswa = "SELECT * FROM siswa ORDER BY id_siswa DESC";
                $resultsiswa = $db->query($sqlsiswa);
                if ($resultsiswa->num_rows > 0) {
                    // Output data dari setiap baris
                    while ($siswa = $resultsiswa->fetch_assoc()) {
                ?>        

                <option value="<?= $siswa["nis"] ?>"><?= $siswa["nis"] ?> - <?= $siswa["nama_siswa"] ?></option>  

                <?php        
                    }
                } else {
                    echo "Tidak ada siswa yang ditemukan.";
                }

                ?>

                </select>
            </div>

            <div class="mb-3">

                <label for="kd_matpel" class="form-label">Kode Mata Pelajaran :</label>
                <select name="kd_matpel" id="kd_matpel"  class="form-control">
                <?php

                // Ambil data dari tabel matpel
                $sqlmatpel = "SELECT * FROM matpel ORDER BY id_matpel DESC";
                $resultmatpel = $db->query($sqlmatpel);
                if ($resultmatpel->num_rows > 0) {
                    // Output data dari setiap baris
                    while ($matpel = $resultmatpel->fetch_assoc()) {
                ?>        

                <option value="<?= $matpel["kd_matpel"] ?>"><?= $matpel["kd_matpel"] ?> - <?= $matpel["nama_matpel"] ?></option>  

                <?php        
                    }
                } else {
                    echo "Tidak ada mata pelajaran yang ditemukan.";
                }

                ?>

                </select>
            </div>

            <div class="mb-3">
                <label for="uts_sem_ganjil" class="form-label">Nilai UTS Ganjil :</label>
                <input type="text" class="form-control" id="uts_sem_ganjil" name="uts_sem_ganjil" required>
            </div>

            <div class="mb-3">
                <label for="uas_sem_ganjil" class="form-label">Nilai UAS Ganjil :</label>
                <input type="text" class="form-control" id="uas_sem_ganjil" name="uas_sem_ganjil" required>
            </div>

            <div class="mb-3">
                <label for="uts_sem_genap" class="form-label">Nilai UTS Genap :</label>
                <input type="text" class="form-control" id="uts_sem_genap" name="uts_sem_genap" required>
            </div>

            <div class="mb-3">
                <label for="uas_sem_genap" class="form-label">Nilai UAS Genap :</label>
                <input type="text" class="form-control" id="uas_sem_genap" name="uas_sem_genap" required>
            </div>

            <input type="submit" value="Tambah Nilai" class="btn btn-success">

        </form>

        <br><br>

    </main>
  </div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
