<?php
define('BASE_URL', 'http://localhost/sahidin/');



?>