<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

// Memproses penghapusan kelas jika ID diberikan
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id_kelas"])) {
    $id_kelas = $_GET["id_kelas"];

    // Membuat query untuk menghapus kelas dari database
    $sql = "DELETE FROM kelas WHERE id_kelas = $id_kelas";

    try {
        if ($db->query($sql) === TRUE) {
            // Kelas berhasil dihapus, tampilkan pesan dan redirect ke halaman utama
            echo "<script>alert('Kelas berhasil dihapus!');</script>";
            echo "<script>window.location.href = 'http://localhost/sahidin/kelas/';</script>";
            exit();
        } else {
            // Gagal menghapus kelas, tampilkan pesan error
            throw new Exception("Gagal menghapus kelas. Kesalahan: " . $db->error);
        }
    } catch (mysqli_sql_exception $e) {
        // Menangkap kesalahan MySQL dan menampilkan pesan kustom
        echo "<script>alert('Error: Tidak dapat menghapus kelas karena terkait dengan data lainnya.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/kelas/';</script>";
        exit();
    } catch (Exception $e) {
        // Menangkap kesalahan lainnya dan menampilkan pesan kustom
        echo "<script>alert('" . $e->getMessage() . "');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/kelas/';</script>";
        exit();
    }
}
?>
