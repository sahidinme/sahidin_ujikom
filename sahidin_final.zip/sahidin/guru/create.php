<?php
include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {  // Mengecek apakah form telah di-submit
    $nip                = $_POST['nip'];  // Mendapatkan nilai NIP dari form
    $nama_guru          = $_POST['nama_guru'];  // Mendapatkan nama guru dari form
    $tempat_lahir_guru  = $_POST['tempat_lahir_guru'];  // Mendapatkan tempat lahir guru dari form
    $tanggal_lahir_guru = $_POST['tanggal_lahir_guru'];  // Mendapatkan tempat lahir guru dari form
    $jenis_kelamin_guru = $_POST['jenis_kelamin_guru'];  // Mendapatkan tanggal lahir guru dari form
    $alamat_guru        = $_POST['alamat_guru'];  // Mendapatkan tanggal lahir guru dari form
    $telp_guru          = $_POST['telp_guru'];  // Mendapatkan tanggal lahir guru dari form
    $kd_matpel          = $_POST['kd_matpel'];  // Mendapatkan kd matpel dari form

    // Query untuk menambahkan guru baru ke database
    $query = "INSERT INTO guru (
    nip, 
    nama_guru, 
    tempat_lahir_guru, 
    tanggal_lahir_guru,  
    jenis_kelamin_guru, 
    alamat_guru, 
    telp_guru, 
    kd_matpel) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);  // Mempersiapkan query
    $stmt->bind_param("issssssi", 
                        $nip, 
                        $nama_guru, 
                        $tempat_lahir_guru,
                        $tanggal_lahir_guru,
                        $jenis_kelamin_guru,
                        $alamat_guru,
                        $telp_guru,
                        $kd_matpel);  // Mengikat parameter

    if ($stmt->execute()) {  // Menjalankan query
        echo "<script>alert('Guru berhasil ditambahkan.');</script>";
    } else {
        echo "Gagal menambahkan guru.";
    }
}

// header
require_once '../tamplate/header.php';
// end header

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
        
        <!-- breadcrumb -->

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>guru">Guru</a></li>
            <li li class="breadcrumb-item active" aria-current="page">Create</li>
            </ol>
        </nav>

        <!-- end breadcrumb -->
        
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Tambah Kelas</h1>
        </div>

        <!-- Form untuk menambah guru baru -->
        <form method="post" action="create.php">

            <div class="mb-3">
                <label for="nip" class="form-label">Nip :</label>
                <input type="text" class="form-control" id="nip" name="nip" required>
            </div>

            <div class="mb-3">
                <label for="nama_guru" class="form-label">Nama Guru :</label>
                <input type="text" class="form-control" id="nama_guru" name="nama_guru" required>
            </div>

            <div class="mb-3">
                <label for="tempat_lahir_guru" class="form-label">Tempat Lahir Guru :</label>
                <input type="text" class="form-control" id="tempat_lahir_guru" name="tempat_lahir_guru" required>
            </div>

            <div class="mb-3">
                <label for="tanggal_lahir_guru" class="form-label">Tanggal Lahir Guru :</label>
                <input type="date" class="form-control" id="tanggal_lahir_guru" name="tanggal_lahir_guru" required>
            </div>

            <div class="mb-3">
                <label for="jenis_kelamin_guru" class="form-label">Jenis Kelamin :</label>
                <select name="jenis_kelamin_guru" id="jenis_kelamin_guru"  class="form-control">
                    <option value="pria">Pria</option>
                    <option value="wanita">Wanita</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="alamat_guru" class="form-label">Alamat Guru :</label>
                <input type="text" class="form-control" id="alamat_guru" name="alamat_guru" required>
            </div>

            <div class="mb-3">
                <label for="telp_guru" class="form-label">No Telp :</label>
                <input type="text" class="form-control" id="telp_guru" name="telp_guru" required>
            </div>

            <div class="mb-3">

                <label for="kd_matpel" class="form-label">Mata Pelajaran :</label>
                <select name="kd_matpel" id="kd_matpel"  class="form-control">
                <?php

                // Ambil data dari tabel matpel
                $sqlmatpel = "SELECT * FROM matpel ORDER BY id_matpel DESC";
                $resultmatpel = $db->query($sqlmatpel);
                if ($resultmatpel->num_rows > 0) {
                    // Output data dari setiap baris
                    while ($matpel = $resultmatpel->fetch_assoc()) {
                ?>        
                
                <option value="<?= $matpel["kd_matpel"] ?>"><?= $matpel["nama_matpel"] ?></option>  
            
                <?php        
                    }
                } else {
                    echo "Tidak ada mata pelajaran yang ditemukan.";
                }

                ?>
                
                </select>
            </div>
            
            <input type="submit" value="Tambah Guru" class="btn btn-success">

        </form>

        <br><br>

    </main>
  </div>
</div>    

<!-- footer -->
<?php require_once '../tamplate/footer.php'; ?>
<!-- end footer -->
