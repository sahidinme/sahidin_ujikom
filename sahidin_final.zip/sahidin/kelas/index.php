<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

// Query untuk membaca data kelas
// $query = "SELECT * FROM kelas";

$query = "SELECT 
                kelas.*, 
                guru.nama_guru 
            FROM 
                kelas 
            JOIN 
                guru 
            ON 
                kelas.nip = guru.nip
            ORDER BY 
                kelas.id_kelas DESC ";
               

$result = $db->query($query);

require_once '../tamplate/header.php';

?>

<!-- side bar -->

<?php require_once '../tamplate/sidebar.php'; ?>

<!-- end sidebar -->

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-3">
    
    <!-- breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-3 bg-body-tertiary rounded-3">
        <li class="breadcrumb-item active"><a href="<?php echo BASE_URL; ?>pelajaran">Kelas</a></li>
        <!-- <li class="breadcrumb-item active" aria-current="page">Data</li> -->
        </ol>
    </nav>
    <!-- end breadcrumb -->
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Kelas</h1>
    </div>

    <div class="alert alert-warning" role="alert">
        <p>Sebelum menghapus data kelas, hapus terlebih dahulu data guru terkait</u>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"  style="float: right;"></button>
        </p>
    </div>

    <?php if ($_SESSION['role'] != 'guru') { ?>
    <h2><a href="create.php" class="btn btn-success">Tambah</a></h2><br>
    <?php } ?>

    <div class="table-responsive">
        <table id="siswaTable" class="table table-striped dt-responsive nowrap" style="width:100%">
          <thead>
            <tr>
                <th>No</th>
                <th>Kode Kelas</th>
                <th>Nama Kelas</th>
                <th>Jumlah Siswa</th>
                <th>Tahun Ajaran</th>
                <th>Nama Guru</th>

                <?php if ($_SESSION['role'] != 'guru') { ?>
                <th>Action</th>
                <?php } ?>

            </tr>
        </thead>
        <tbody>
            <?php $i = "1"; if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $row['kd_kelas']; ?></td>
                        <td><?= $row['nama_kelas']; ?></td>
                        <td><?= $row['jumlah_siswa']; ?></td>
                        <td><?= $row['tahun_ajaran']; ?></td>
                        <td><?= $row['nama_guru']; ?></td>

                        <?php if ($_SESSION['role'] != 'guru') { ?>
                        <td class="action-buttons">
                            <a href="update.php?id_kelas=<?= $row['id_kelas']; ?>" class="btn btn-warning">Update</a>
                            <a href="delete.php?id_kelas=<?= $row['id_kelas']; ?>" class="btn btn-danger">Delete</a>
                        </td>
                        <?php } ?>

                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">Tidak ada data kelas.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        </table>

        <br><br>
    </div>
      
      </main>
    </div>
  </div>    
  
  <!-- footer -->
  <?php
  
  require_once '../tamplate/footer.php';
  
  ?>

  <!-- end footer -->

  
