<?php
include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

// Memproses penghapusan artikel jika ID diberikan
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id_absen"])) {
    $id_absen = $_GET["id_absen"];

    // Membuat query untuk menghapus absen dari database
    $sql = "DELETE FROM absen WHERE id_absen = $id_absen";

    if ($db->query($sql) === TRUE) {
        // Artikel berhasil dihapus, tampilkan pesan dan redirect ke halaman utama
        echo "<script>alert('Absen berhasil dihapus!');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/absen/';</script>";
        exit();
    } else {
        // Gagal menghapus absen, tampilkan pesan error
        echo "Error: " . $sql . "<br>" . $db->error;
    }
}


?>
