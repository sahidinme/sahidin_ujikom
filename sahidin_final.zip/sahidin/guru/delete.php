<?php
include_once '../config/config.php';  // Menghubungkan file konfigurasi database
include_once '../config/database.php';  // Menghubungkan file konfigurasi database

// hak akses
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: ../login.php");
    exit();
}

$database = new Database();  // Membuat objek database
$db = $database->getConnection();  // Mendapatkan koneksi ke database

// Memproses penghapusan artikel jika ID diberikan
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id_guru"])) {
    $id_guru = $_GET["id_guru"];

    // Membuat query untuk menghapus guru dari database
    $sql = "DELETE FROM guru WHERE id_guru = $id_guru";

    try {
        if ($db->query($sql) === TRUE) {
            // Guru berhasil dihapus, tampilkan pesan dan redirect ke halaman utama
            echo "<script>alert('Guru berhasil dihapus!');</script>";
            echo "<script>window.location.href = 'http://localhost/sahidin/guru/';</script>";
            exit();
        } else {
            // Gagal menghapus guru, tampilkan pesan error
            throw new Exception("Gagal menghapus guru. Kesalahan: " . $db->error);
        }
    } catch (mysqli_sql_exception $e) {
        // Menangkap kesalahan MySQL dan menampilkan pesan kustom
        echo "<script>alert('Error: Tidak dapat menghapus guru karena terkait dengan data lainnya.');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/guru/';</script>";
        exit();
    } catch (Exception $e) {
        // Menangkap kesalahan lainnya dan menampilkan pesan kustom
        echo "<script>alert('" . $e->getMessage() . "');</script>";
        echo "<script>window.location.href = 'http://localhost/sahidin/guru/';</script>";
        exit();
    }
}
?>
